# multi_sensitivity.py
# --------------------------------------------------------
# Compare LS, HEFT, BOS(0), BOS(δ) for 10 seeds
# Output CSV + printed summary

import csv
from statistics import mean, stdev

from scheduler.instance_generator import generate_instance
from scheduler.algorithms.list_scheduling import list_scheduling
from scheduler.algorithms.heft import heft
from scheduler.algorithms.bos_greedy import bos_greedy

H = 6
b = 3
m = 4

seeds = [101, 202, 303, 404, 505, 606, 707, 808, 909, 1001]
deltas = [0.0, 0.1, 0.3, 0.5]

results = []

print("\n=== Multi-Algorithm Scheduling Experiment ===")
print(f"H={H}, b={b}, m={m}, seeds={len(seeds)}")
print("------------------------------------------------\n")

for sd in seeds:
    inst = generate_instance(H=H, b=b, seed=sd)

    ls_c = list_scheduling(inst, m=m)
    heft_c = heft(inst, m=m)
    bos0 = bos_greedy(inst, m=m, alpha=0.0)

    row = {
        "seed": sd,
        "LS": ls_c,
        "HEFT": heft_c,
        "BOS(0)": bos0
    }

    print(f"Seed={sd}, LS={ls_c:.4f}, HEFT={heft_c:.4f}, BOS(0)={bos0:.4f}")

    # also run δ versions
    for delta in deltas:
        bos_c = bos_greedy(inst, m=m, alpha=delta)
        row[f"BOS({delta})"] = bos_c

    results.append(row)

print("\n=== SUMMARY ===")

summary = {}

keys = ["LS", "HEFT", "BOS(0)", "BOS(0.0)", "BOS(0.1)", "BOS(0.3)", "BOS(0.5)"]

# Convert results into column-wise statistics
stats = {}
for key in keys:
    arr = []
    for r in results:
        if key in r:
            arr.append(r[key])
        elif key == "BOS(0.0)" and "BOS(0)" in r:
            arr.append(r["BOS(0)"])
    if arr:
        stats[key] = {
            "avg": mean(arr),
            "std": stdev(arr),
            "min": min(arr),
            "max": max(arr)
        }

# Print summary
for key, v in stats.items():
    print(f"{key:10s} | avg={v['avg']:.3f} | std={v['std']:.3f} | min={v['min']:.3f} | max={v['max']:.3f}")

# Write CSV
csv_path = "multi_algorithm_results.csv"
with open(csv_path, "w", newline="") as f:
    writer = csv.writer(f)
    header = ["seed"] + list(keys)
    writer.writerow(header)
    for r in results:
        row = [r["seed"]] + [r.get(k, "") for k in keys]
        writer.writerow(row)

print(f"\nCSV saved: {csv_path}")
