# parallel.py
# 多核心平行運算工具

from multiprocessing import Pool

def parallel_run(func, tasks, workers=8):
    with Pool(workers) as p:
        return p.map(func, tasks)
