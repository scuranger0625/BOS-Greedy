# bottleneck_shift_experiment.py
# --------------------------------------------------------
# 4.5.3 Bottleneck Shifting Scenarios
# 模擬「瓶頸層塞車」前後，各演算法 Cmax 增幅的差異

import csv
from statistics import mean, stdev

from scheduler.instance_generator import generate_instance
from scheduler.algorithms.list_scheduling import list_scheduling
from scheduler.algorithms.heft import heft
from scheduler.algorithms.bos_greedy import bos_greedy


# ---------- 幫 BOS 重新計算 D[i] 的工具 ----------

def recompute_D(n, p, children, layers):
    """
    D[i] = 從 i 出發到終端的 longest path 長度
    """
    D = [0.0] * n
    for layer in reversed(layers):
        for u in layer:
            if not children[u]:
                D[u] = p[u]
            else:
                D[u] = p[u] + max(D[c] for c in children[u])
    return D


class SimpleInstance:
    """
    用來在相同 precedence 結構下替換 processing time p 的小 wrapper
    """
    def __init__(self, base_inst, p_override=None):
        self.n = base_inst.n
        self.parents = base_inst.parents
        self.children = base_inst.children
        self.layers = base_inst.layers

        # 新增：H 給 HEFT 用
        self.H = len(base_inst.layers)

        # 新的 processing time
        if p_override is None:
            self.p = base_inst.p
        else:
            self.p = p_override

        # 重新計算 D，給 BOS 用
        self.D = recompute_D(self.n, self.p, self.children, self.layers)



# ---------- 實驗設定 ----------

H = 6
b = 3
m = 4

seeds = [101, 202, 303, 404, 505, 606, 707, 808, 909, 1001]
gamma = 0.5   # 塞車比例：p' = (1+gamma) * p

alg_names = ["LS", "HEFT", "BOS(0)", "BOS(0.3)", "BOS(0.5)"]

print("\n=== Bottleneck Shifting Experiment ===")
print(f"H={H}, b={b}, m={m}, seeds={len(seeds)}, gamma={gamma}")
print("--------------------------------------------------------\n")

results = []   # 存每個 seed 的 base / congested / ratio


for sd in seeds:
    base_inst = generate_instance(H=H, b=b, seed=sd)
    n = base_inst.n
    p_base = list(base_inst.p)  # 複製一份

    # ---- 1. 找出 load 最大的瓶頸層 ----
    layer_loads = []
    for layer in base_inst.layers:
        load = sum(p_base[i] for i in layer)
        layer_loads.append(load)
    bottleneck_layer_idx = max(range(len(layer_loads)),
                               key=lambda h: layer_loads[h])
    bottleneck_layer = base_inst.layers[bottleneck_layer_idx]

    # ---- 2. 在瓶頸層上製造塞車：p' = (1+gamma)*p ----
    p_cong = p_base.copy()
    for u in bottleneck_layer:
        p_cong[u] = p_cong[u] * (1.0 + gamma)

    # ---- 3. 建立 base / congested 兩個 instance ----
    inst_base = SimpleInstance(base_inst, p_override=p_base)
    inst_cong = SimpleInstance(base_inst, p_override=p_cong)

    # ---- 4. 各演算法在 base / congested 的 Cmax ----
    row = {"seed": sd}

    # LS
    C_ls_base = list_scheduling(inst_base, m=m)
    C_ls_cong = list_scheduling(inst_cong, m=m)
    row["LS_base"] = C_ls_base
    row["LS_cong"] = C_ls_cong
    row["LS_ratio"] = C_ls_cong / C_ls_base

    # HEFT
    C_heft_base = heft(inst_base, m=m)
    C_heft_cong = heft(inst_cong, m=m)
    row["HEFT_base"] = C_heft_base
    row["HEFT_cong"] = C_heft_cong
    row["HEFT_ratio"] = C_heft_cong / C_heft_base

    # BOS(0)
    C_bos0_base = bos_greedy(inst_base, m=m, alpha=0.0)
    C_bos0_cong = bos_greedy(inst_cong, m=m, alpha=0.0)
    row["BOS0_base"] = C_bos0_base
    row["BOS0_cong"] = C_bos0_cong
    row["BOS0_ratio"] = C_bos0_cong / C_bos0_base

    # BOS(0.3)
    C_bos03_base = bos_greedy(inst_base, m=m, alpha=0.3)
    C_bos03_cong = bos_greedy(inst_cong, m=m, alpha=0.3)
    row["BOS03_base"] = C_bos03_base
    row["BOS03_cong"] = C_bos03_cong
    row["BOS03_ratio"] = C_bos03_cong / C_bos03_base

    # BOS(0.5)
    C_bos05_base = bos_greedy(inst_base, m=m, alpha=0.5)
    C_bos05_cong = bos_greedy(inst_cong, m=m, alpha=0.5)
    row["BOS05_base"] = C_bos05_base
    row["BOS05_cong"] = C_bos05_cong
    row["BOS05_ratio"] = C_bos05_cong / C_bos05_base

    results.append(row)

    print(f"Seed={sd} | "
          f"LS ratio={row['LS_ratio']:.3f}, "
          f"HEFT ratio={row['HEFT_ratio']:.3f}, "
          f"BOS0 ratio={row['BOS0_ratio']:.3f}, "
          f"BOS0.3 ratio={row['BOS03_ratio']:.3f}, "
          f"BOS0.5 ratio={row['BOS05_ratio']:.3f}")


# ---------- 統計 summary ----------

def collect_ratios(key):
    return [r[key] for r in results]


summary = {
    "LS":    collect_ratios("LS_ratio"),
    "HEFT":  collect_ratios("HEFT_ratio"),
    "BOS(0)":  collect_ratios("BOS0_ratio"),
    "BOS(0.3)": collect_ratios("BOS03_ratio"),
    "BOS(0.5)": collect_ratios("BOS05_ratio"),
}

print("\n=== Ratio Summary (C_cong / C_base) ===")
for name, arr in summary.items():
    avg_r = mean(arr)
    std_r = stdev(arr)
    print(f"{name:8s} | avg_ratio={avg_r:.4f} | std={std_r:.4f} "
          f"| min={min(arr):.4f} | max={max(arr):.4f}")


# ---------- 輸出 CSV ----------

csv_path = "bottleneck_shift_results.csv"
with open(csv_path, "w", newline="") as f:
    writer = csv.writer(f)
    header = [
        "seed",
        "LS_base", "LS_cong", "LS_ratio",
        "HEFT_base", "HEFT_cong", "HEFT_ratio",
        "BOS0_base", "BOS0_cong", "BOS0_ratio",
        "BOS03_base", "BOS03_cong", "BOS03_ratio",
        "BOS05_base", "BOS05_cong", "BOS05_ratio",
    ]
    writer.writerow(header)
    for r in results:
        writer.writerow([
            r["seed"],
            r["LS_base"], r["LS_cong"], r["LS_ratio"],
            r["HEFT_base"], r["HEFT_cong"], r["HEFT_ratio"],
            r["BOS0_base"], r["BOS0_cong"], r["BOS0_ratio"],
            r["BOS03_base"], r["BOS03_cong"], r["BOS03_ratio"],
            r["BOS05_base"], r["BOS05_cong"], r["BOS05_ratio"],
        ])

print(f"\nCSV saved: {csv_path}")
