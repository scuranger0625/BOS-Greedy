# scheduler/tools/critical_path.py
# 計算 DAG 的「真實最長路徑長度」L0（不含 δ）

def compute_critical_path_length(instance):
    n = instance.n
    p = instance.p
    parents = instance.parents
    children = instance.children
    layers = instance.layers  # 已經是拓樸排序

    # L[u] = processing time + max parent L
    L = [0.0] * n

    # 因為 instance.layers 本身就是 topological order
    for layer in layers:
        for u in layer:
            if len(parents[u]) == 0:
                L[u] = p[u]
            else:
                L[u] = p[u] + max(L[p] for p in parents[u])

    return max(L)
