# experiment_static.py
# 靜態 BOM 實驗入口

def run_static_experiment():
    pass
