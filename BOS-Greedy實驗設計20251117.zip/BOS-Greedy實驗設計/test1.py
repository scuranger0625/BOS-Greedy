from scheduler.instance_generator import generate_instance
from scheduler.algorithms.bos_greedy import bos_greedy
from scheduler.algorithms.ls import list_scheduling
from scheduler.algorithms.heft import heft

# 關鍵！！！換成更大的 BOM，δ 才會有效果
inst = generate_instance(H=6, b=3, seed=123)

print("n =", inst.n)
print("LS     =", list_scheduling(inst, m=4))
print("HEFT   =", heft(inst, m=4))

for alpha in [0.0, 0.1, 0.3, 0.5]:
    print(f"BOS δ={alpha} =", bos_greedy(inst, m=4, alpha=alpha))
