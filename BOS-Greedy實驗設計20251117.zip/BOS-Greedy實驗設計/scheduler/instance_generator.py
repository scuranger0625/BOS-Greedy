# instance_generator.py — Version 3.2 (Industrial BOM, n≈300, stable)
import random
from dataclasses import dataclass

@dataclass
class Instance:
    n: int
    H: int
    layers: list
    parents: list
    children: list
    p: list
    lead: list
    release: list
    D: list


def generate_instance(H=6, b=3, seed=None, target_n=300):
    """
    Industrial BOM Generator V3.2
    - 目標 DAG 大小 ≈ target_n（預設 300）
    - 每層多 cluster（多父、多路徑）
    - heavy-tail processing times (Pareto)
    - cross-layer edges
    - FIX: parent 數量不足時避免 random.randint 爆掉
    """
    if seed is not None:
        random.seed(seed)

    H = max(3, H)
    target_n = max(150, target_n)

    # -------------------------------------------------------
    # 1. 先決定每層大小
    # -------------------------------------------------------
    layer_sizes = [1]
    remaining = target_n - 1

    for h in range(1, H):
        if h == 1:
            size = random.randint(15, 25)
        else:
            prev = layer_sizes[h-1]
            factor = random.uniform(1.6, 2.3)
            size = int(prev * factor)

        size = max(8, size)
        if size > remaining:
            size = remaining

        layer_sizes.append(size)
        remaining -= size

        if remaining <= 0:
            break

    if remaining > 0:
        layer_sizes[-1] += remaining

    layers = []
    node_id = 0
    for sz in layer_sizes:
        layer_nodes = list(range(node_id, node_id + sz))
        layers.append(layer_nodes)
        node_id += sz

    n = node_id

    # -------------------------------------------------------
    # 2. 父子關係（上一層 → 下一層）
    # -------------------------------------------------------
    parents = [[] for _ in range(n)]
    children = [[] for _ in range(n)]

    max_parents = max(3, b + 2)

    for h in range(1, len(layers)):
        upper = layers[h-1]
        lower = layers[h]

        for v in lower:
            max_k = min(max_parents, len(upper))
            if max_k <= 1:
                k = 1
            else:
                k = random.randint(2, max_k)

            chosen = random.sample(upper, k)
            for u in chosen:
                parents[v].append(u)
                children[u].append(v)

    # -------------------------------------------------------
    # 3. Cross-layer edges: h → h+2
    # -------------------------------------------------------
    for h in range(len(layers) - 2):
        layer_a = layers[h]
        layer_b = layers[h+2]

        jump_edges = random.randint(1, max(1, len(layer_a) // 3))
        for _ in range(jump_edges):
            u = random.choice(layer_a)
            v = random.choice(layer_b)
            parents[v].append(u)
            children[u].append(v)

    # -------------------------------------------------------
    # 4. Heavy-tail processing time （Pareto）
    # -------------------------------------------------------
    p = []
    for i in range(n):
        xm = 5.0
        alpha = 1.8
        u = random.random()
        proc = xm / (u ** (1.0 / alpha))
        p.append(proc)

    # -------------------------------------------------------
    # 5. lead & release
    # -------------------------------------------------------
    lead = [random.uniform(0, 5) for _ in range(n)]
    release = [0.0] * n

    # -------------------------------------------------------
    # 6. Compute D[i]（剩餘 longest path）
    # -------------------------------------------------------
    D = [0.0] * n
    for layer in reversed(layers):
        for u in layer:
            if not children[u]:
                D[u] = p[u]
            else:
                D[u] = p[u] + max(D[v] for v in children[u])

    return Instance(
        n=n,
        H=len(layers),
        layers=layers,
        parents=parents,
        children=children,
        p=p,
        lead=lead,
        release=release,
        D=D
    )
