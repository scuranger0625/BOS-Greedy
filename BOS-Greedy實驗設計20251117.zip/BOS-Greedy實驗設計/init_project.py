import os

folders = [
    "scheduler",
    "scheduler/algorithms",
    "experiments",
    "results"
]

files = {
    "scheduler/instance_generator.py": """# instance_generator.py
# 生成 BOM / DAG / processing time / precedence
# 目前先放骨架，由你之後填入細節

class Instance:
    def __init__(self, n, H, b, p, parents, children, layers):
        self.n = n
        self.H = H
        self.b = b
        self.p = p
        self.parents = parents
        self.children = children
        self.layers = layers

def generate_instance(H=5, b=3, p_dist='lognormal', seed=None):
    # TODO: 生成多階 BOM + DAG + 處理時間 + adjacency list
    pass
""",

    "scheduler/metrics.py": """# metrics.py
# Cmax / LB / Lδ / approximation ratio / stability

def compute_lb(P, m, L_delta):
    return max(P/m, L_delta)

def approx_ratio(Cmax, LB):
    return Cmax / LB if LB > 0 else None

def stability_variance(values):
    # values: list of Cmax under different scenarios
    # TODO: add real variance calculation
    pass
""",

    "scheduler/algorithms/bos_greedy.py": """# bos_greedy.py
# 事件驅動 BOS-Greedy（骨架）

def bos_greedy(instance, m=4, delta=0.0):
    # TODO: event-driven scheduling core loop
    pass
""",

    "scheduler/algorithms/ls.py": """# ls.py
# List Scheduling baseline

def list_scheduling(instance, m=4):
    # TODO: topological order + greedy assign
    pass
""",

    "scheduler/algorithms/heft.py": """# heft.py
# HEFT baseline

def heft(instance, m=4):
    # TODO: rank_u / earliest finish heuristic
    pass
""",

    "scheduler/algorithms/sbp.py": """# sbp.py
# Shifting Bottleneck Procedure（簡化版）

def sbp(instance, m=4):
    # TODO: simplified SBP heuristic
    pass
""",

    "scheduler/scenarios.py": """# scenarios.py
# 動態瓶頸 / 機器故障 / 隨機延遲場景

def apply_random_congestion(instance):
    # TODO: modify p_i or add delays
    pass

def apply_machine_breakdown(instance):
    # TODO: generate machine events
    pass
""",

    "scheduler/runner.py": """# runner.py
# 單一 instance 跑多個演算法

from scheduler.algorithms.bos_greedy import bos_greedy
from scheduler.algorithms.ls import list_scheduling
from scheduler.algorithms.heft import heft
from scheduler.algorithms.sbp import sbp

def run_all_algorithms(instance, m=4, delta=0.0):
    results = {}
    results["BOS"] = bos_greedy(instance, m=m, delta=delta)
    results["LS"]  = list_scheduling(instance, m=m)
    results["HEFT"] = heft(instance, m=m)
    results["SBP"] = sbp(instance, m=m)
    return results
""",

    "experiments/experiment_static.py": """# experiment_static.py
# 靜態 BOM 實驗入口

def run_static_experiment():
    pass
""",

    "experiments/experiment_delta.py": """# experiment_delta.py
# δ-overlap sensitivity

def run_delta_experiment():
    pass
""",

    "experiments/experiment_bottleneck.py": """# experiment_bottleneck.py
# 動態瓶頸場景實驗

def run_bottleneck_experiment():
    pass
""",

    "experiments/experiment_scalability.py": """# experiment_scalability.py
# scalability experiment

def run_scalability_experiment():
    pass
""",

    "experiments/parallel.py": """# parallel.py
# 多核心平行運算工具

from multiprocessing import Pool

def parallel_run(func, tasks, workers=8):
    with Pool(workers) as p:
        return p.map(func, tasks)
"""
}

# create folders
for folder in folders:
    os.makedirs(folder, exist_ok=True)

# create files
for path, content in files.items():
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

print("Project structure generated successfully.")
