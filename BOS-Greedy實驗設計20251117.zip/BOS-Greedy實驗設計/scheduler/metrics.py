# metrics.py
# Cmax / LB / Lδ / approximation ratio / stability

def compute_lb(P, m, L_delta):
    return max(P/m, L_delta)

def approx_ratio(Cmax, LB):
    return Cmax / LB if LB > 0 else None

def stability_variance(values):
    # values: list of Cmax under different scenarios
    # TODO: add real variance calculation
    pass
