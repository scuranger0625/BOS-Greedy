# runner.py
# 單一 instance 跑多個演算法

from scheduler.algorithms.bos_greedy import bos_greedy
from scheduler.algorithms.ls import list_scheduling
from scheduler.algorithms.heft import heft
from scheduler.algorithms.sbp import sbp

def run_all_algorithms(instance, m=4, delta=0.0):
    results = {}
    results["BOS"] = bos_greedy(instance, m=m, delta=delta)
    results["LS"]  = list_scheduling(instance, m=m)
    results["HEFT"] = heft(instance, m=m)
    results["SBP"] = sbp(instance, m=m)
    return results
