# scenarios.py
# 動態瓶頸 / 機器故障 / 隨機延遲場景

def apply_random_congestion(instance):
    # TODO: modify p_i or add delays
    pass

def apply_machine_breakdown(instance):
    # TODO: generate machine events
    pass
