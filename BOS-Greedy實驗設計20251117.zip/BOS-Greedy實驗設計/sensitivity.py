# sensitivity.py
# --------------------------------------------
# δ-overlap sensitivity experiment
# Runs 10 random seeds × δ ∈ {0, 0.1, 0.3, 0.5}
# Outputs CSV + printed summary

import csv
from statistics import mean, stdev

from scheduler.instance_generator import generate_instance
from scheduler.algorithms.bos_greedy import bos_greedy
from scheduler.algorithms.list_scheduling import list_scheduling
from scheduler.algorithms.heft import heft

# 想要更大規模，你可以改 H, b, m
H = 6
b = 3
m = 4

seeds = [101, 202, 303, 404, 505, 606, 707, 808, 909, 1001]
deltas = [0.0, 0.1, 0.3, 0.5]

results = []

print("\n=== δ-overlap Sensitivity Experiment ===")
print(f"H={H}, b={b}, m={m}, seeds={len(seeds)}")
print("----------------------------------------\n")

for delta in deltas:
    row = {"delta": delta, "makespans": []}

    for sd in seeds:
        inst = generate_instance(H=H, b=b, seed=sd)

        makespan = bos_greedy(inst, m=m, alpha=delta)
        row["makespans"].append(makespan)

        print(f"δ={delta:0.1f}, seed={sd}, Cmax={makespan:.4f}")

    results.append(row)
    print("")

# summary
summary = []
for r in results:
    delta = r["delta"]
    arr = r["makespans"]
    summary.append({
        "delta": delta,
        "avg": mean(arr),
        "std": stdev(arr),
        "min": min(arr),
        "max": max(arr)
    })

# write CSV
csv_path = "delta_sensitivity_results.csv"
with open(csv_path, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["delta", "avg", "std", "min", "max"])
    for s in summary:
        writer.writerow([s["delta"], s["avg"], s["std"], s["min"], s["max"]])

print("\n=== Summary (Across 10 Seeds) ===")
for s in summary:
    print(f"δ={s['delta']:0.1f} | avg={s['avg']:.4f} | std={s['std']:.4f} "
          f"| min={s['min']:.4f} | max={s['max']:.4f}")

print(f"\nCSV saved: {csv_path}")
