from scheduler.instance_generator import generate_instance
from scheduler.tools.critical_path import compute_critical_path_length

inst = generate_instance(H=6, b=3, seed=123)

L0 = compute_critical_path_length(inst)
print("n =", inst.n)
print("Critical Path Length L0 =", L0)
