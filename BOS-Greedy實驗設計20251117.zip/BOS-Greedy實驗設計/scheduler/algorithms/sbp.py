# sbp.py
# Shifting Bottleneck Procedure（簡化版）

def sbp(instance, m=4):
    # TODO: simplified SBP heuristic
    pass
